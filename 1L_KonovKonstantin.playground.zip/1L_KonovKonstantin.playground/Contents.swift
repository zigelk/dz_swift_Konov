import UIKit

var str = "Hello, playground"
// 1) решение квадратного уровнения 4x2-4x+1
var a : Float = 4
var b : Float = -4
var c : Float = 1
// найдем дискриминант
var discrim : Float = (b*b)-a*a*c
// найдем первый корень
var xOne = -(b)/(2*a)
// так как дискриминант равен 0, ответ имеет два совпадающих корня
var xTwo = xOne
/*2) даны катеты прямоугольного треугольника. найти площадь периметр и гепотенузу треугольника*/
var ac : Double = 3
var bc : Double = 4
// найдем гипотенузу
var abPodKornem : Double = (ac*ac)+(bc*bc)
var ab = sqrt(abPodKornem)
// найдем периметр
var per = ac+bc+ab
//найдем площадь
var ploshad = (ac*bc)/2
/*3)пользователь вводит сумму вклада и годовой процент,найти сумму вклада через 5 лет*/
var sum = 100_000
var procentYear = 5
let itogSum = (sum/100)*(procentYear*5)+sum

